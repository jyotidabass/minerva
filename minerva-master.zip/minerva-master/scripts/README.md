Scripts for learning task and system inspecting
===============================================

* `learning` folder contains scripts for training, testing, visualizing, etc.
* `system` folder contains scrips for DAG and log analysis
