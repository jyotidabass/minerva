Tutorial
========

NArray objects
--------------

Dataflow and lazy evaluation
----------------------------

Interact with Numpy
--------------------

Training Example: MNIST
-----------------------

Training Example: ImageNet
--------------------------
