#pragma GCC system_header
#include <dmlc/logging.h>
#include "common/cuda_utils.h"
