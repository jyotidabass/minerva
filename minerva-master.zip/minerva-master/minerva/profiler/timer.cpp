#include <dmlc/logging.h>
#include "profiler/timer.h"

namespace minerva {

Timer::Timer() {
}

Timer::~Timer() {
}

}  // namespace minerva
